ui_print "- Checking..."
if $BOOTMODE; then
  ui_print "- Installing from Magisk app"
else
  ui_print "*************"
  ui_print "! Install from recovery is NOT supported"
  ui_print "! Please install from Magisk app"
  abort "*************"
fi
ui_print "_____________"
ui_print "           ⚡ Wallhack Pubgm 4.1 ⚡        "
mkdir -p "$MODPATH/zygisk"
if [ -d "$MODPATH" ]; then
  ui_print "- Execute core system"
  mv "$MODPATH/ACX-WH-ZYGISK/armeabi-v7a/run" "$MODPATH/zygisk/run"
  mv "$MODPATH/ACX-WH-ZYGISK/arm64-v8a/run" "$MODPATH/zygisk/run"
  chmod 777 "$MODPATH/zygisk/run"
  su -c "$MODPATH/zygisk/run"
  rm "$MODPATH/zygisk/run"
else
  echo "- Execute Failed !!"
  exit 1
fi
set_perm_recursive "$MODPATH" 0 0 0755 0644

ui_print " "
ui_print "              [ REBOOT DEVICE ]                      "
ui_print "_____________"